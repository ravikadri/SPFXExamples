﻿namespace EmailNotificationBot.Models
{
    public class InitialCardOptions
    {
        public string createdBy { get; set; }
        public string serviceName { get; set; }
        public string imagePath { get; set; }
        public string createdByUserID { get; set; }
    }
}
