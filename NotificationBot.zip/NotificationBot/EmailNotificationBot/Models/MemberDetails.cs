﻿namespace EmailNotificationBot.Models
{
    public class MemberDetails
    {
        public string value { get; set; }
        public string title { get; set; }
    }
}
