using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Teams;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;

namespace EmailNotificationBot
{
    /// <summary>
    /// An empty bot handler.
    /// You can add your customization code here to extend your bot logic if needed.
    /// </summary>
    public class TeamsBot : TeamsActivityHandler
    {
       public override Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default) =>
           Task.CompletedTask;




        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext,
                   CancellationToken cancellationToken)
        {

            if (turnContext.Activity.RemoveRecipientMention().ToLower() == "request")
            {
                //Capture this user as the owner of the asset and send the base approval request card with approve button
                var attachment = new Attachment
                {


                };

                var messageActivity = MessageFactory.Attachment(attachment);

                await turnContext.SendActivityAsync(messageActivity);

            }




        }



    }


   
}
