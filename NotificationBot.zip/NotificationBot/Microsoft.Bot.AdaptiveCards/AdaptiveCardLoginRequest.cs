﻿namespace Microsoft.Bot.AdaptiveCards
{
    public class AdaptiveCardLoginRequest
    {
        public string LoginUrl { get; set; }
    }
}
