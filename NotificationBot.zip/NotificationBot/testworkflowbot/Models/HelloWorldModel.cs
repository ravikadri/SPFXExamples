﻿namespace testworkflowbot.Models
{
    public class HelloWorldModel
    {
        public string Title { get; set; }

        public string Body { get; set; }
    }
}
